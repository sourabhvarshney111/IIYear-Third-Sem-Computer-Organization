#include<stdio.h>
void main()
{
        int decimal1,decimal2;
        int binary1[32]={0},binary2[32]={0},binary[32]={0},rem=0,res=0;
        printf("Enter the Decimal number1:");
        scanf("%d",&decimal1);
        int i=0,temp;
	if(decimal1<0)
		temp=-decimal1;
	else
		temp=decimal1;
        while(temp)
        {
               binary1[i++]=temp%2;
               temp/=2; 
        }
        for(i=0;i<16;i++)
        {
                temp=binary1[i];
                binary1[i]=binary1[32-i-1];
                binary1[32-i-1]=temp;
        }
	if(decimal1<0)
	{
		for(i=31;i>=0;i--)
			if(binary1[i]==1)
			{
				while(--i>=0)
					binary1[i]^=1;
			}
	}
        printf("Enter the Decimal number2:");
        scanf("%d",&decimal2);
        if(decimal2<0)
		temp=-decimal2;
	else
		temp=decimal2;
        i=0;
        while(temp)
        {
               binary2[i++]=temp%2;
               temp/=2; 
        }
        for(i=0;i<16;i++)
        {
                temp=binary2[i];
                binary2[i]=binary2[32-i-1];
                binary2[32-i-1]=temp;
        }
	if(decimal2<0)
	{
		for(i=31;i>=0;i--)
			if(binary2[i]==1)
			{
				while(--i>=0)
					binary2[i]^=1;
			}
	}
        printf("The binary equivalent of %d is:",decimal1);
        for(i=0;i<32;i++)
                printf("%d",binary1[i]);
        printf("\n");
        printf("The binary equivalent of %d is:",decimal2);
        for(i=0;i<32;i++)
                printf("%d",binary2[i]);
        printf("\n");
        for(i=31;i>=0;i--)
        {
                binary[i]=(binary1[i]+binary2[i]+rem)%2;
                rem=(binary1[i]+binary2[i]+rem)/2;
        }
	printf("The binary addition in binary is:");
	for(i=0;i<32;i++)
                printf("%d",binary[i]);
        printf("\n");
        printf("The binary addition is:");
        int j=1;
        for(i=31;i>=0;i--)
        {
                res+=binary[i]*j;
                j*=2;
        }
        printf("%d",res);
        printf("\n");
}
