#include<stdio.h>
void main()
{
        int a;
        printf("Enter the number:");
        scanf("%d",&a);
        printf("Percentage 6 d format: %6d\n",a);
	printf("Short Decimal format: %hi\n",a);
}
