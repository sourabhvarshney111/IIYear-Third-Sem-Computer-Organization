#include<stdio.h>
void main()
{
        unsigned int a;
        printf("Enter the number:");
        scanf("%d",&a);
        printf("Octal Format:%o\n",a);
        printf("Hexadecimal format:%x\n",a);
}
