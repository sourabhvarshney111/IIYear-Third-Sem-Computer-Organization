#include<stdio.h>
int main()
{
        unsigned int a,b;
        int d,i=0,temp;
        int ar1[32]={0},ar2[32]={0},result[32]={0};
        int res=0;
        printf("Enter Two Unsigned Integers:");
        scanf("%u %u",&a,&b);
        temp=a;
        while(temp)
        {
               ar1[i++]=temp%2;
               temp/=2; 
        }
        for(i=0;i<16;i++)
        {
                temp=ar1[i];
                ar1[i]=ar1[32-i-1];
                ar1[32-i-1]=temp;
        }
        i=0;
        temp=b;
        while(temp)
        {
               ar2[i++]=temp%2;
               temp/=2; 
        }
        for(i=0;i<16;i++)
        {
                temp=ar2[i];
                ar2[i]=ar2[32-i-1];
                ar2[32-i-1]=temp;
        }
        printf("The binary of %d is: ",a);
        for(i=0;i<32;i++)
                printf("%d",ar1[i]);
        printf("\n");
        printf("The binary of %d is: ",b);
        for(i=0;i<32;i++)
                printf("%d",ar2[i]);
        printf("\n");
        printf("Operation Menu:\n");
        printf("1.And\n");
        printf("2.Or\n");
        printf("3.Xor\n");
        printf("4.Xnor\n");
        printf("Enter your choice:");
        scanf("%d",&d);
        switch(d)
        {
                case 1: for(i=0;i<32;i++)
                        result[i]=ar1[i]&ar2[i];
                        break;
                case 2: for(i=0;i<32;i++)
                        result[i]=ar1[i]|ar2[i];
                        break;
                case 3: for(i=0;i<32;i++)
                        result[i]=ar1[i]^ar2[i];
                        break;
                case 4: for(i=0;i<32;i++)
                        result[i]=!(ar1[i]^ar2[i]);
                        break;
                default: printf("Wrong Choice:");
                         break;
        }
        printf("The Result of operation in binary is:");
        int j=1;
        for(i=31;i>=0;i--)
        {
                res+=result[i]*j;
                j*=2;
        }
        for(i=0;i<32;i++)
                printf("%d",result[i]);
        printf("\n");
        printf("The Result of operation in decimal is:");
        printf("%d\n",res);
}
