#include<stdio.h>
#include<math.h>
int main()
{
        long long temp,binary;
        int decimal=0;
        long long i=1;
        printf("Enter the binary Number:");
        scanf("%lld",&binary);
        temp=binary;
        while(temp)
        {
                if(temp%10>1)
                {
                        printf("Binary Number cannot contain numbers other than 0 or 1\n");
                        return 1;
                }
                decimal+=(temp%10)*i;
                temp/=10;
                i*=2;
        }
        printf("The decimal equivalent of %lld is %d\n",binary,decimal);
        return 0;
 }
        
