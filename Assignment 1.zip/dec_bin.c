#include<stdio.h>
void main()
{
        int decimal;
        int binary[32]={0};
        printf("Enter the Decimal number:");
        scanf("%d",&decimal);
        int i=0,temp=decimal;
        while(temp)
        {
               binary[i++]=temp%2;
               temp/=2; 
        }
        int n=i;
        for(i=0;i<(n/2);i++)
        {
                temp=binary[i];
                binary[i]=binary[n-i-1];
                binary[n-i-1]=temp;
        }
        printf("The binary equivalent of %d is:",decimal);
        for(i=0;i<n;i++)
                printf("%d",binary[i]);
        printf("\n");
}
